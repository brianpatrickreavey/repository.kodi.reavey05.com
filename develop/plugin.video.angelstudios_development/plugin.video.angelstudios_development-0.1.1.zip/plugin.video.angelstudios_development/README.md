# angelstudios-kodi
Angel Studios KODI Addon

Initial commit from basic testing code.

For each revision, update the `version.txt` file.  The `addon.xml` will be updated
to match when you run the `build.sh` script.

# For development environment
linking in Linux