# Copyright (C) 2025, Brian Patrick Reavey
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""
Angel Studios Kodi addon - Clean, modular implementation
"""

import sys
import os
import xbmcvfs  # type: ignore

# Ensure the dependencies directory is in the path for bundled dependencies
lib_path = os.path.join(os.path.dirname(__file__), "../dependencies")
sys.path.insert(0, lib_path)

from urllib.parse import parse_qsl

import xbmcaddon  # type: ignore
import xbmcgui  # type: ignore

from angel_interface import AngelStudiosInterface
from angel_authentication import AuthenticationCore, Auth0Config, KodiSessionStore
from kodi_utils import KodiLogger
from kodi_ui_interface import KodiUIInterface

# Ensure the dependencies directory is in the path for bundled dependencies
lib_path = os.path.join(os.path.dirname(__file__), "../dependencies")
sys.path.insert(0, lib_path)

# Plugin constants
URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()

# Instantiate the logger with debug promotion settings
promote_all_debug = ADDON.getSettingBool("debug_promote_all")

# Define category-to-setting mapping
category_settings = {
    "art": "debug_art_promotion",
    "timing": "debug_timing_promotion",
    "api": "debug_api_promotion",
    "cache": "debug_cache_promotion",
}

# Load category promotions from settings
category_promotions = {}
for category, setting_id in category_settings.items():
    try:
        category_promotions[category] = ADDON.getSettingBool(setting_id)
    except Exception:
        category_promotions[category] = False

# Load general promotion settings
uncategorized_promotion = ADDON.getSettingBool("debug_uncategorized_promotion")
miscategorized_promotion = ADDON.getSettingBool("debug_miscategorized_promotion")

logger = KodiLogger(
    promote_all_debug=promote_all_debug,
    category_promotions=category_promotions,
    uncategorized_promotion=uncategorized_promotion,
    miscategorized_promotion=miscategorized_promotion,
)


def auth_step_logger():
    """Return the Kodi logger only when the user has opted in.

    Login steps include the Angel email and the callback URL. The callback
    URL contains a one-time login code. Warn once each time the setting is
    turned on, before any of those lines are written.
    """
    enabled = ADDON.getSettingBool("log_auth_steps")
    warned = ADDON.getSettingBool("log_auth_steps_warned")
    if not enabled:
        if warned:
            ADDON.setSettingBool("log_auth_steps_warned", False)
        return None
    if not warned:
        message = ADDON.getLocalizedString(30526) or (
            "Authentication logging is on. kodi.log will include your Angel email "
            "address and the login callback URL. That URL contains a one-time login code. "
            "If Kodi debug logging is on, or if Promote all debug or Promote uncategorized "
            "debug is on, the log also includes the start of your login token. "
            "Do not share kodi.log while this setting is on."
        )
        xbmcgui.Dialog().ok("Angel Studios", message)
        ADDON.setSettingBool("log_auth_steps_warned", True)
    return logger


# Create Angel Studios interface
angel_interface = None

# ui_interface will be created in main guard

# Get credentials from addon settings once at module load
USERNAME = ADDON.getSettingString("username")
PASSWORD = ADDON.getSettingString("password")
TIMEOUT = ADDON.getSettingInt("request_timeout")

# The main menu still opens when the username or password is empty, so Guild
# Voting can say "Sign in to vote." Catalog actions keep the configure dialog.
_ACTIONS_WITHOUT_CREDENTIALS = {
    None,
    "settings",
    "show_information",
    "guild_voting_menu",
    "guild_voted_menu",
    "play_torch",
    "play_voted_torch",
    "install_widevine",
}

# These actions do not read the catalog or the Guild. Signing in first would
# delay them, and logout must not create a new session on the way out.
# "info" is the unavailable-episode message. "show_information" is the
# session dialog. Both stay on the token that is already saved.
_ACTIONS_WITHOUT_LOGIN_REFRESH = {
    "settings",
    "clear_cache",
    "install_widevine",
    "force_logout",
    "clear_debug_data",
    "info",
    "show_information",
}


def refresh_saved_login(auth_core, action):
    """Sign in again when the saved token is missing or expired.

    A token that is still valid does not contact Angel. A failed sign-in
    leaves the addon open. The new token is saved before the interface is built.
    """
    if not USERNAME or not PASSWORD:
        return
    if action in _ACTIONS_WITHOUT_LOGIN_REFRESH:
        return
    try:
        already_valid = auth_core.validate_session() is True
    except Exception as exc:
        logger.warning(f"Saved login check failed ({type(exc).__name__})")
        already_valid = False
    if already_valid:
        return
    logger.info("Saved login expired. Signing in again.")
    try:
        auth_core.ensure_valid_session()
        refreshed = auth_core.validate_session() is True
    except Exception as exc:
        logger.warning(f"Could not refresh the saved login ({type(exc).__name__})")
        return
    if refreshed:
        logger.info("Saved login refreshed")
    else:
        logger.warning("Could not refresh the saved login")


def router(paramstring, ui_interface, resume=False):
    """
    Router function that calls other functions based on the provided paramstring
    Main menu offers content browsing options and special menus mimicing the Angel.com website:
    - Series
    - Movies
    - Dry Bar Comedy Specials
    - Podcasts
    - Livestreams
    - Currently Watching
    - Savced/Favorites
    - All content
    """
    # Parse URL parameters
    params = dict(parse_qsl(paramstring))
    logger.info(f"Router called with params: {params}")

    try:
        # Route to appropriate function
        if not params:
            ui_interface.main_menu()
        else:
            if params["action"] == "movies_menu":
                # Show movies
                ui_interface.projects_menu(content_type="movies")
            elif params["action"] == "series_menu":
                # Show series
                ui_interface.projects_menu(content_type="series")
            elif params["action"] == "specials_menu":
                # Show Dry Bar Comedy Specials
                ui_interface.projects_menu(content_type="specials")
            elif params["action"] == "podcast_menu":
                # Show Podcasts
                ui_interface.projects_menu(content_type="podcasts")
            elif params["action"] == "livestream_menu":
                # Show Livestreams
                ui_interface.projects_menu(content_type="livestreams")
            elif params["action"] == "watchlist_menu":
                ui_interface.watchlist_menu()
            elif params["action"] == "add_to_watchlist":
                ui_interface.add_to_watchlist(params.get("content_id", ""))
            elif params["action"] == "remove_from_watchlist":
                ui_interface.remove_from_watchlist(params.get("content_id", ""))
            elif params["action"] == "continue_watching_menu":
                # Show Continue Watching with optional pagination cursor
                after = params.get("after")
                ui_interface.continue_watching_menu(after=after)
            elif params["action"] == "top_picks_menu":
                # Show Top Picks (placeholder)
                ui_interface.top_picks_menu()
            elif params["action"] == "guild_voting_menu":
                ui_interface.guild_voting_menu()
            elif params["action"] == "guild_voted_menu":
                ui_interface.guild_voted_menu(after=params.get("after"))
            elif params["action"] == "play_torch":
                ui_interface.play_torch(params["torch_id"])
            elif params["action"] == "play_voted_torch":
                ui_interface.play_voted_torch(params["torch_id"])
            elif params["action"] == "all_content_menu":
                # Show all content (except podcasts & livestreams)
                # all_content_menu()
                pass
            elif params["action"] == "seasons_menu":
                # Show seasons for a project
                ui_interface.seasons_menu(params["content_type"], params["project_slug"])
            elif params["action"] == "episodes_menu":
                # Show episodes for a season using individual parameters
                ui_interface.episodes_menu(
                    params["content_type"], params["project_slug"], params.get("season_id")
                )
            elif params["action"] == "play_episode":
                # Play an episode, movie, or special. Continue Watching leaves content_type empty.
                # resume is true when Kodi's own dialog, or the player setting, chose Resume.
                ui_interface.play_episode(
                    params["episode_guid"],
                    params["project_slug"],
                    content_type=params.get("content_type", ""),
                    resume=resume,
                )
            elif params["action"] == "info":
                # Show info message for unavailable episodes
                message = params.get("message", "This content is not available.")
                ui_interface.show_error(message)
            elif params["action"] == "settings":
                # Open addon settings dialog
                ADDON.openSettings()
            elif params["action"] == "clear_cache":
                logger.info("Settings: clear_cache button pressed")
                ui_interface.clear_cache_with_notification()
            elif params["action"] == "install_widevine":
                logger.info("Settings: install_widevine button pressed")
                ui_interface.install_widevine()
            elif params["action"] == "force_logout":
                logger.info("Settings: force_logout button pressed")
                ui_interface.force_logout_with_notification()
            elif params["action"] == "clear_debug_data":
                logger.info("Settings: clear_debug_data button pressed")
                ui_interface.clear_debug_data_with_notification()
            elif params["action"] == "show_information":
                ui_interface.show_auth_details_dialog()
            else:
                # Unknown action
                raise ValueError(f'Invalid action: {params.get("action", "unknown")}')

    except KeyError as e:
        logger.error(f"Missing required parameter: {e}")
        ui_interface.show_error(f"Missing parameter: {str(e)}")
    except Exception as e:
        logger.error(f"Router error: {e}")
        ui_interface.show_error(f"Navigation error: {str(e)}")


def main():
    """Main addon entry point"""
    logger.info(f"Addon invoked with argv: {sys.argv}")

    action = dict(parse_qsl(sys.argv[2][1:])).get("action")
    if (not USERNAME or not PASSWORD) and action not in _ACTIONS_WITHOUT_CREDENTIALS:
        # Show error if credentials are not set
        xbmcgui.Dialog().ok(
            "Angel Studios",
            "Please configure your Angel.com username and password in the addon settings.",
        )
    else:
        # Initialize UI interface
        ui_interface = KodiUIInterface(HANDLE, URL, logger=logger, angel_interface=None)

        try:
            # Call the router function with plugin parameters
            # Initialize Angel Studios authentication with session management

            # Get the query path for GraphQL queries (relatvie to the addon path)
            query_path = xbmcvfs.translatePath(
                ADDON.getAddonInfo("path") + "/resources/lib/angel_graphql/"
            )
            logger.info(f"Using query path: {query_path}")

            # Initialize AuthenticationCore with Kodi session store
            config = Auth0Config(
                base_url="https://www.angel.com",
                user_agent=None,
                request_timeout=TIMEOUT,
            )
            auth_logger = auth_step_logger()
            auth_core = AuthenticationCore(  # type: ignore
                session_store=KodiSessionStore(ADDON), config=config, logger=auth_logger
            )
            # Refresh before the interface reads the token, so the menu and
            # the next request both see the new login.
            refresh_saved_login(auth_core, action)

            # Initialize Angel Studios interface with authentication core
            asi = AngelStudiosInterface(
                logger=logger,
                auth_core=auth_core,
                query_path=query_path,
                tracer=ui_interface.get_trace_callback(),
                timeout=TIMEOUT,
            )
            # Initialize UI helper
            logger.info(f"Setting Angel Interface for Kodi UI {asi}")
            ui_interface.setAngelInterface(asi)

            # Call the router with parameters from the command line
            logger.info(f"Calling router with params: {sys.argv[2][1:]}")
            # Kodi always passes resume:true or resume:false. Directory listings use false.
            resume = len(sys.argv) > 3 and sys.argv[3] == "resume:true"
            router(sys.argv[2][1:], ui_interface, resume=resume)

        except Exception as e:
            logger.error(f"Addon initialization error: {e}")
            ui_interface.show_error(f"Addon failed to start: {str(e)}")


if __name__ == "__main__":
    main()
