# kodi.plugin.video.crossfitwod
KODI Addon to display the Crossfit WOD and link to movement videos
