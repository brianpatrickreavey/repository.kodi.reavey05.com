# kodi.plugin.video.crossfitwod
KODI Addon to display the Crossfit WOD and link to movement videos

# Timer function
Choose:
* AMRAP, EMOM, Tabita, etc.
* Time for intervals, etc.
* Workout playlist
* Cooldown playlist
* Alarm sound
* 1 minute warning, half way warning, etc.
* Dispaly timer, round, and WOD Rx

# TODO
* Refactor to use the list of workouts (more reliable) rather than the WOD
link that seems to be broken half the time.
* Rename the app WODI (like WODI, but for WODs)

