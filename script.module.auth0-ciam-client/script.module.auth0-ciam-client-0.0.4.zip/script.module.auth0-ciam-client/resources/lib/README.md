# auth0_ciam_client Package Directory

This directory contains the `auth0_ciam_client` Python package code, which is checked out from the [auth0-ciam-client repository](https://github.com/brianpatrickreavey/auth0-ciam-client) during CI builds and addon packaging.

In development, this is a symlink to the local library repository. In CI/release, the actual source files are copied here to bundle the package with the Kodi addon.