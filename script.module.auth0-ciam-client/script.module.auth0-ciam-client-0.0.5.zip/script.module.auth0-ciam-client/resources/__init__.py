# Kodi addon resources
